var str = '';

str += '<meta http-equiv="X-UA-Compatible" content="IE=edge" />';
str += '<meta name="viewport" content="width=device-width, viewport-fit=cover" />';
str += '<meta name="theme-color" content="#6684EA" />';
str += '<meta name="author" content="세종엔" />';
str += '<title>세종엔</title>';
str += '<link rel="stylesheet" href="../../public/styles/swiper-bundle.min.css" />';
str += '<link rel="stylesheet" href="../../public/styles/gbSin.css"/>';
str += '<link rel="stylesheet" href="../../public/styles/gbInfo.css" />';
str += '<link rel="stylesheet" href="../../public/styles/gbMap.css" />';
str += '<link rel="stylesheet" href="../../public/styles/globals.css" />';
str += '<script src="../js//swiper-bundle.min.js"></script>';
str += '<script src="../js/slider.js"></script>';
str += '<script src="../js/ui.js"></script>';

document.write(str);