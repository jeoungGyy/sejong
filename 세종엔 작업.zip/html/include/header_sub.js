var str = '';

str += '<header class="header">';
str += '  <div class="subHeader">';
str += '    <button type="button" class="icoPrev"><i>이전 페이지</i></button>';
str += '    <h2></h2>';
str += '    <button type="button" class="icoPicture"><i>사진 목록보기</i></button>';
str += '    <button type="button" class="icoClose"><i>닫기</i></button>';
str += '  </div>';
str += '</header>';

document.write(str);