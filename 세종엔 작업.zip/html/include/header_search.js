var str = '';

str += '<header class="header">';
str += '  <div class="subHeader">';
str += '    <button type="button" class="icoPrev"><i>이전 페이지</i></button>';
str += '    <div class="searchHeader">';
str += '      <input type="text" title="장소, 버스 검색" placeholder="장소, 버스 검색" />';
str += '    </div>';
str += '    <div class="btnHeader">';
str += '      <button type="button" class="icoMic"><i>마이크</i></button>';
str += '      <button type="button" class="icoReset" style="display:none"><i>초기화</i></button>';
str += '    </div>';
str += '  </div>';
str += '</header>';

document.write(str);