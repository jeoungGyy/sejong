var str = '';

str += '	<footer class="footer">';
str += '		<div class="area">';
str += '		    <p>푸터</p>';
str += '		</div>';
str += '	</footer>';


document.write(str);
